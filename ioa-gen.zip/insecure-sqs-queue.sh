#!/bin/bash

random=$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 13 ; echo)
random=$(echo $random | tr '[:upper:]' '[:lower:]')
sqs_stub="-horizon-example"
sqs_name="$random$sqs_stub"

echo "Creating SQS Queue with an insecure configuration"
result=$(aws sqs create-queue --queue-name $sqs_name --attributes '{ "MessageRetentionPeriod": "259200" }' --region us-west-2)
if ! [ -z "$result" ]
then
    echo "SQS queue $result has been created"
else
    echo "Unable to create SQS queue"
fi
