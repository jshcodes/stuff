#!/bin/bash

bucket_region="us-east-1"
random=$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 13 ; echo)
random=$(echo $random | tr '[:upper:]' '[:lower:]')
bucket_stub="-horizon-example"
bucket_name="$random$bucket_stub"

echo "Creating bucket $bucket_name with an insecure configuration"
# Create a simple bucket without encryption or retention policies
result=$(aws s3api create-bucket --bucket $bucket_name --region $bucket_region)

if [[ "$result" =~ .*"$bucket_name".* ]]
then
    # Generate a publicly accessible bucket policy in JSON format as a stand-alone file
    echo "{" > $random.json
    echo "    'Version': '2012-10-17'," >> $random.json
    echo "    'Statement': [" >> $random.json
    echo "        {" >> $random.json
    echo "            'Sid': 'PublicRead'," >> $random.json
    echo "            'Effect': 'Allow'," >> $random.json
    echo "            'Principal': '*'," >> $random.json
    echo "            'Action': [" >> $random.json
    echo "                's3:GetObject'," >> $random.json
    echo "                's3:GetObjectVersion'" >> $random.json
    echo "            ]," >> $random.json
    echo "            'Resource': 'arn:aws:s3:::$bucket_name/*'" >> $random.json
    echo "        }" >> $random.json
    echo "    ]" >> $random.json
    echo "}" >> $random.json

    # Clean up the quotes
    sed -i '' "s/'/\"/g" $random.json
    # Apply the policy to the bucket
    aws s3api put-bucket-policy --bucket $bucket_name --policy file://$random.json
    # Remove our policy JSON file
    rm $random.json
    echo "Bucket created successfully."
else
    echo "Bucket creation failed."
fi


