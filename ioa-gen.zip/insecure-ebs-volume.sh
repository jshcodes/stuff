#!/bin/bash
avail_zone="us-west-2a"
random=$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 13 ; echo)
random=$(echo $random | tr '[:upper:]' '[:lower:]')
ebs_stub="-horizon-example"
ebs_name="$random$ebs_stub"

echo "Creating EBS volume with an insecure configuration"
result=$(aws ec2 create-volume --volume-type gp2 --size 5 --availability-zone "$avail_zone" --tag-specifications "ResourceType=volume,Tags=[{Key=Name,Value=$ebs_name}]")

if [[ "$result" =~ .*"$ebs_name".* ]]
then
    echo "Volume $ebs_name created successfully in $avail_zone."
else
    echo "Unabe to create volume"
fi
