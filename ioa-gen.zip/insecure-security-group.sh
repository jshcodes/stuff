#!/bin/bash
​
random=$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 13 ; echo)
random=$(echo $random | tr '[:upper:]' '[:lower:]')
sg_stub="-horizon-example"
sg_name="$random$sg_stub"
aws_region=us-west-2
​
# Grab our VPC ID
​
vpc_id=$(aws ec2 describe-vpcs --filter Name=tag:Name,Values=VPC-horizon-demo-stack --query Vpcs[].VpcId --output text --region $aws_region)
​
​
if [ -z "$vpc_id" ]
then
    echo "Unable to determine VPC ID"
else
    echo "Creating Security Group $sg_name with an insecure configuration in VPC $vpc_id"
    # Create a simple Security Group
    sg_id=$(aws ec2 create-security-group --group-name $sg_name --description "Horizon testing" --vpc-id $vpc_id --region $aws_region --output text)
    if [ -z "$sg_id" ]
    then
        echo "Unable to create security group"
    else
        echo "Applying permissions to Security Group $sg_id"
        if $(aws ec2 authorize-security-group-ingress --group-id $sg_id --protocol tcp --port 22 --cidr 0.0.0.0/0 --region $aws_region)
        then
            echo "Security group permissions set successfully"
        else
            echo "Unable to apply security group permissions"
        fi
    fi
fi